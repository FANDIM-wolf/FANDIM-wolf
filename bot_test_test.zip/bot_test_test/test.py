import telebot;
from telebot import types
import psycopg2
from psycopg2 import Error, connect
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT
import sqlite3 
import datetime
import random

files = []

#init token 
bot = telebot.TeleBot('5235250024:AAFn1MHDZy31aF9izO7U74trm1roqB_5NLg')
brand = " "
token = '5235250024:AAFn1MHDZy31aF9izO7U74trm1roqB_5NLg'
brands = ["get_teneleven" , "get_joe_lo", "get_jasson_lo","get_topface" ,"get_miss_tais" , "get_fabio" , "get_belucci" , "get_elitario"]

#start function to start conversation with bot
@bot.message_handler(content_types=['photo'])
def handle_docs_photo(message):
    file_info = bot.get_file(message.photo[len(message.photo) - 1].file_id)
    downloaded_file = bot.download_file(file_info.file_path)
    src = 'files/' + file_info.file_path
    print(file_info.file_path)
    files.append(file_info.file_path)
    with open(src, 'wb') as new_file:
        new_file.write(downloaded_file)

    bot.reply_to(message, "Пожалуй, я сохраню это")



@bot.message_handler(content_types=['text'])
def start(message):
    if message.text == "/start":
        bot.send_message(message.from_user.id , text="Здравствуйте, благодарим за обращение.Мы намерены как можно скорее разобраться в вашем вопросе.Для этого, пожалуйста, предоставьте несколько уточнений:")
        keyboard = types.InlineKeyboardMarkup() 
        key_indigrient_one = types.InlineKeyboardButton(text='Wildberries' , callback_data='get_wildberries')
        keyboard.add(key_indigrient_one)
        key_indigrient_two = types.InlineKeyboardButton(text='Ozon' , callback_data='get_ozon')
        keyboard.add(key_indigrient_two)
        key_indigrient_three = types.InlineKeyboardButton(text='KazanExpress' , callback_data='get_kazanexpress')
        keyboard.add(key_indigrient_three)
        bot.send_message(message.from_user.id , text="Где вы оформляли заказ?" , reply_markup=keyboard)
    if message.text == "/send_photos":
        for i in range(len(files)):
            photo=open('files/'+files[i] , 'rb')
            bot.send_photo(message.from_user.id , photo)

def get_category(call):
    keyboard = types.InlineKeyboardMarkup() 
    key_indigrient_one = types.InlineKeyboardButton(text='Одежда ' , callback_data='get_clothes')
    keyboard.add(key_indigrient_one)
    key_indigrient_two = types.InlineKeyboardButton(text='Косметика' , callback_data='get_cosmetics')
    keyboard.add(key_indigrient_two)
    key_indigrient_three = types.InlineKeyboardButton(text='Музыкальные инструменты' , callback_data='get_musician_tools')
    keyboard.add(key_indigrient_three)
    bot.send_message(call.from_user.id , text="Выберите категорию, к которой относится ваш товар:" , reply_markup=keyboard)
def get_brand(call ,brand ):
    if brand == "get_clothes":
        keyboard = types.InlineKeyboardMarkup() 
        key_indigrient_one = types.InlineKeyboardButton(text='Teneleven ' , callback_data='get_teneleven')
        keyboard.add(key_indigrient_one)
        key_indigrient_two = types.InlineKeyboardButton(text='Joe lo' , callback_data='get_joe_lo')
        keyboard.add(key_indigrient_two)
        key_indigrient_three = types.InlineKeyboardButton(text='Jasson lo' , callback_data='get_jasson_lo')
        keyboard.add(key_indigrient_three)
        bot.send_message(call.from_user.id , text="Выберите категорию, к которой относится ваш товар:" , reply_markup=keyboard)
    if brand == "get_cosmetics":
        keyboard = types.InlineKeyboardMarkup() 
        key_indigrient_one = types.InlineKeyboardButton(text='Topface ' , callback_data='get_topface')
        keyboard.add(key_indigrient_one)
        key_indigrient_two = types.InlineKeyboardButton(text='Miss Tais' , callback_data='get_misstais')
        keyboard.add(key_indigrient_two)
        bot.send_message(call.from_user.id , text="Выберите категорию, к которой относится ваш товар:" , reply_markup=keyboard)
    if brand == "get_musican":
        keyboard = types.InlineKeyboardMarkup() 
        key_indigrient_one = types.InlineKeyboardButton(text='Fabio' , callback_data='get_fabio')
        keyboard.add(key_indigrient_one)
        key_indigrient_two = types.InlineKeyboardButton(text='Belucci' , callback_data='get_belucci')
        keyboard.add(key_indigrient_two)
        key_indigrient_three = types.InlineKeyboardButton(text='Elitaro' , callback_data='get_elitaro')
        keyboard.add(key_indigrient_three)
        bot.send_message(call.from_user.id , text="Выберите категорию, к которой относится ваш товар:" , reply_markup=keyboard)
#display menu where user can choose reason his dissatisfaction
def choose_reason(call):
    keyboard = types.InlineKeyboardMarkup() 
    key_indigrient_one = types.InlineKeyboardButton(text='- Задержка доставки - Поврежденная упаковка' , callback_data='delay_and_damaged_box')
    keyboard.add(key_indigrient_one)
    key_indigrient_two = types.InlineKeyboardButton(text='Дефект не влияющй на основную функцию продукта ' , callback_data='not_base_function')
    keyboard.add(key_indigrient_two)
    key_indigrient_three = types.InlineKeyboardButton(text='Дефект делающий использование продукта невозможным' , callback_data='base_function')
    keyboard.add(key_indigrient_three)
    key_indigrient_fourth = types.InlineKeyboardButton(text='Несоответствие цвета/описания' , callback_data='color_or_description')
    keyboard.add(key_indigrient_fourth)
    bot.send_message(call.from_user.id , text="Выберите из перечня причину инцидента:" , reply_markup=keyboard)


@bot.callback_query_handler(func=lambda call:True)
def callback_handler(call):
    global brand
    if call.data == "get_wildberries":
        get_category(call)
        
    if call.data == "get_ozon":
        get_category(call)
    if call.data == "get_kazanexpress":
        get_category(call)
    if call.data == "get_clothes":
        brand = call.data 
        get_brand(call , brand)
    if call.data == "get_cosmetics":
        brand = call.data
        get_brand(call , brand)
    if call.data == "get_musican":
        brand = call.data
        get_brand(call , brand) 
    if call.data in brands:
        print(call.data)
        choose_reason(call)

           
#start bot 
bot.polling(none_stop=True , interval=0)        