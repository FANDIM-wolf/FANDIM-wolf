<!Doctype html>
<html>
<head>

</head>
<body>
<h1>Shishov union base</h1>
<img src="img/Shishov.png">

</body>
</html><?php /**PATH D:\database\union_shishov_base\resources\views/main.blade.php ENDPATH**/ ?>