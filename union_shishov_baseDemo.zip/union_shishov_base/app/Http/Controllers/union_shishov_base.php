<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class union_shishov_base extends Controller
{
    //get main page of base 
    public function get_main_page(){
        return view('main');
    }
}
