<!Doctype html>
<html>
    <head>
        <title>LMK ARCHIVE</title>
        <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Lato&display=swap" rel="stylesheet">
<link href="css/style.css" rel="stylesheet" >
    </head>
<body>
<header>
        <div class="inner">
            <div class="logo">
                <div>
                    
                    <h3>
                      ЛМК АРХИВ
                  </h3>
                    
                </div>
            </div>

            <nav>
                
                <li><span><a href="">Файлы для скачивания</a></span></li>
                @if($user->type == "педагог")
                <li><span><a href="/upload">Загрузить файлы</a></span></li>
                @endif
                <li><span><a href="">О приложении</a></span></li>
                
                
            </nav>
        </div>
    </header>  


<main> 

@if( $user->type == "педагог")
<form method="POST" action="/upload" enctype="multipart/form-data">
    @csrf
        <br>
        <input type="file" name="file"><br>
        <input type="text" name="file_name" placeholder="Имя файла" ><br> 
       
        <select name="group">
        <option value="КСК 18-1">КСК 18-1</option>
        <option value="КСК 18-2">КСК 18-2</option>
        <option value="КСК 18-3">КСК 18-3</option>
        <option value="ИСиП 18-1">ИСиП 18-1</option>
        <option value="ИСиП 18-2">ИСиП 18-2</option>
        <option value="ИСиП 18-3">ИСиП 18-3</option>
        </select>
        <button type="submit">Загрузить</button>
    
</form>

<form action="/upload_files" method="post" enctype="multipart/form-data">
{{ csrf_field() }}
<div class="form-group">
<label for="Product Name">Несколько файлов:</label>
<br />
<input type="file" class="form-control" name="files[]" multiple />
<br /><br />

<select name="group">
    <option value="КСК 18-1">КСК 18-1</option>
    <option value="КСК 18-2">КСК 18-2</option>
    <option value="КСК 18-3">КСК 18-3</option>
    <option value="ИСиП 18-1">ИСиП 18-1</option>
    <option value="ИСиП 18-2">ИСиП 18-2</option>
    <option value="ИСиП 18-3">ИСиП 18-3</option>
</select>
<input type="submit" class="btn btn-primary" value="Загрузить" />
</form>
@endif
@if($user->type == "студент")
 <h2>Извините , но студент не может загружать файлы на сервер.</h2>
 <img src="img/pepe.gif" width=450 height=350/>
@endif
</main>
</body>
</html>