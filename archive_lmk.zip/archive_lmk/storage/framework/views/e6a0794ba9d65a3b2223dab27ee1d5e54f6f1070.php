<!Doctype html>
<html>
    <head>
        <title>LMK ARCHIVE</title>
        <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Lato&display=swap" rel="stylesheet">
<link href="css/style.css" rel="stylesheet" >
<link href="js/script.js" rel="stylesheet" >

    </head>
<body>

 <header>
        <div class="inner">
            <div class="logo">
                <div>
                
                    <h3 id="click_menu">
                      ЛМК АРХИВ
                  </h3>
                    
                </div>
            </div>

            <nav>
                
                <li><span><a href="">Файлы для скачивания</a></span></li>
                <?php if($user->type == "педагог"): ?>
                <li><span><a href="/upload">Загрузить файлы</a></span></li>
                <?php endif; ?>
                <li><span><a href="">О приложении</a></span></li>
                
                
            </nav>
        </div>
    </header>
    <div class="menu" id="menu">
        <h3><a id="link" href="">Файлы для скачивания</a></h3>
        <?php if($user->type == "педагог"): ?>
        <h3><a id="link" href="/upload">Загрузить файлы</a></span></h3>
        <?php endif; ?>
        <h3><a id="link" href="/login">Войти</a></span></h3>
    </div>
    <div id="main">   
   
    <h2>Файлы доступные для скачивания:</h2>

    <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a class="link" href="download/<?php echo e($document->name_file); ?>/from_hub">Файл:<?php echo e($document->name_file); ?></a><br>
    <p>Группа <?php echo e($document->group_user); ?></p> 
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    
    </div>

  

    <script text="javascript">
    
 
     alert("Hello");
     var div_menu = document.getElementById("menu");
     var click_button = document.getElementById("click_menu"); 
     console.log(div_menu);
 console.log(click_button);
    
    
 
 // display div or close it .
          
         click_button.onclick= function(){
             
            div_menu.classList.toggle("open");
         }
       
 </script>

</body>
</html><?php /**PATH D:\archive_lmk\archive_lmk\resources\views/main.blade.php ENDPATH**/ ?>