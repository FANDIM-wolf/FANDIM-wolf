alert("Hello");
var div_menu = document.getElementByClassName("menu");
console.log(div_menu);
// display div or close it .
 		
         div_menu.onclick = function (){
            div_menu.classList.toggle("open");
       }

