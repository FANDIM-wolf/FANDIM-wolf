package com.ScienceEva;

public class BiologyPackage extends MathPackage {

    @Override
    public  void  GreetUserInConsole(){
        System.out.println("Biology object");
    }
}
